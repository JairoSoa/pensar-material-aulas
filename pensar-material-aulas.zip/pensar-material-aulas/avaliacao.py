#!/usr/bin/env python3
"""Pensar Cursos: gera a avaliacao final (10 questoes, A a D) em Word simples, com a resposta abaixo de cada questao.

Uso:
  python3 avaliacao.py avaliacao.json PASTA_SAIDA

avaliacao.json:
{
  "curso": "Nome do Curso",
  "questoes": [
    {"enunciado": "Texto da questao", "alternativas": ["A", "B", "C", "D"], "correta": "C"},
    ... (exatamente 10)
  ]
}
"""
import json, sys
from collections import Counter
from pathlib import Path

import docx
from docx.shared import Pt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from converter import slug  # noqa: E402

LETRAS = "ABCD"


def checar(d):
    erros = []
    qs = d.get("questoes", [])
    if len(qs) != 10:
        erros.append(f"sao {len(qs)} questoes; precisam ser 10.")
    for i, q in enumerate(qs, 1):
        if not q.get("enunciado", "").strip():
            erros.append(f"questao {i}: enunciado vazio.")
        alts = q.get("alternativas", [])
        if len(alts) != 4 or any(not a.strip() for a in alts):
            erros.append(f"questao {i}: precisa de 4 alternativas preenchidas.")
        if len(set(a.strip().lower() for a in alts)) != len(alts):
            erros.append(f"questao {i}: alternativas repetidas.")
        if str(q.get("correta", "")).upper() not in LETRAS:
            erros.append(f"questao {i}: 'correta' deve ser A, B, C ou D.")
    cont = Counter(str(q.get("correta", "")).upper() for q in qs)
    if qs and len(cont) < 3:
        erros.append(f"respostas concentradas demais ({dict(cont)}); distribua entre A, B, C e D.")
    if qs and max(cont.values()) > 4:
        erros.append(f"uma letra aparece {max(cont.values())} vezes como correta; use no maximo 4.")
    return erros


def maiuscula(t):
    t = t.strip()
    return t[:1].upper() + t[1:]


def gerar(dados_json, saida):
    d = json.load(open(dados_json, encoding="utf8"))
    erros = checar(d)
    if erros:
        sys.exit("Avaliacao com problemas:\n" + "\n".join(erros))
    saida = Path(saida)
    saida.mkdir(parents=True, exist_ok=True)
    doc = docx.Document()
    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.font.size = Pt(11)
    t = doc.add_paragraph()
    r = t.add_run(f"Avaliação final: {d['curso']}")
    r.bold = True
    r.font.size = Pt(14)
    for i, q in enumerate(d["questoes"], 1):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(12)
        rr = p.add_run(f"Questão {i}. ")
        rr.bold = True
        p.add_run(q["enunciado"].strip())
        for letra, alt in zip(LETRAS, q["alternativas"]):
            a = doc.add_paragraph(f"{letra}) {maiuscula(alt)}")
            a.paragraph_format.left_indent = Pt(14)
            a.paragraph_format.space_after = Pt(2)
        resp = doc.add_paragraph()
        rr = resp.add_run(f"Resposta: {str(q['correta']).upper()}")
        rr.bold = True
    destino = saida / f"Avaliacao_final_{slug(d['curso'], 60)}.docx"
    doc.save(destino)
    print("Gerado:", destino.name)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    gerar(sys.argv[1], sys.argv[2])
