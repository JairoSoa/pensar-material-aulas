# pensar-material-aulas

Converte o material de um curso do Pensar Cursos (.docx) em um arquivo por aula, no layout oficial, e gera a ementa.

- `modelos/layout.dotx`: modelo das folhas (cabeçalho, marca d'água e rodapé).
- `modelos/ementa.dotx`: modelo do Programa do Curso.
- `assets/`: ícones das caixas e ícones das aberturas de capítulo (`icons.json` lista os nomes).
- `converter.py`: `analisar`, `gerar` e `verificar` (veja o topo do arquivo).
- `ementa.py`: preenche a ementa a partir de um `ementa.json`.
- `avaliacao.py`: gera a avaliação final (10 questões, A a D) a partir de um `avaliacao.json`.

Requisitos: Python 3 com python-docx, lxml e Pillow; LibreOffice (`soffice`); `pdftoppm`; fonte Poppins em `/usr/share/fonts/truetype/google-fonts/`.

Fluxo:
```bash
python3 converter.py analisar curso.docx plano.json
python3 converter.py gerar curso.docx plano.json saida
python3 converter.py verificar saida
python3 ementa.py ementa.json saida
```
