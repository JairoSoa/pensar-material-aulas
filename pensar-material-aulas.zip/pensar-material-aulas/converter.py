#!/usr/bin/env python3
"""Pensar Cursos: transforma o material de um curso (.docx) em um arquivo por aula.

Uso:
  python3 converter.py analisar CURSO.docx plano.json
  python3 converter.py gerar CURSO.docx plano.json PASTA_SAIDA
  python3 converter.py verificar PASTA_SAIDA

analisar: le o curso, identifica apresentacao, unidades, capitulos e parte final,
          e grava um plano.json com nome do curso e um icone sugerido por capitulo.
gerar:    tudo em Word: Aula 01 (pagina 1 em branco, Apresentacao + Capitulo 1),
          Aulas 02..N e Encerramento (Conclusao, Glossario, Leituras, Referencias),
          todos no modelo de layout do Pensar Cursos.
verificar: gera uma folha de miniaturas por arquivo para conferencia visual.
"""
import copy, glob, json, os, re, shutil, subprocess, sys, tempfile, unicodedata, uuid, zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import docx
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls, qn
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
MODELOS = ROOT / "modelos"
ASSETS = ROOT / "assets"
NS = nsdecls("w", "r", "wp", "a", "pic")

# ---------------------------------------------------------------- design
INDIGO, VIOLETA, CIANO, NAVY = "3022A8", "5840D0", "00A8D8", "1B2A6B"
TEXTO, TEXTO_SUAVE = "262A40", "4A4F6A"
LARGURA = 8504  # largura util em twips (A4 com margens de 3 cm)
FONTE_TITULO, FONTE_CORPO = "Poppins", "Calibri"

CAIXAS = {  # chave: (prefixo no titulo, badge, cor do titulo, fundo)
    "objetivos": ("OBJETIVOS", "objetivos", INDIGO, "EEECFB"),
    "conceito": ("CONCEITO", "conceito", "0A5BD8", "E8F1FE"),
    "atencao": ("ATENÇÃO", "atencao", "C2410C", "FFF1E7"),
    "lei": ("O QUE DIZ A LEI", "lei", NAVY, "EDF0F7"),
    "exemplo": ("EXEMPLO", "exemplo", "0377A0", "E6F7FC"),
    "dica": ("DICA", "dica", "15803D", "EAF7EE"),
    "caso": ("ESTUDO DE CASO", "caso", VIOLETA, "F1EEFC"),
    "resumo": ("RESUMO", "resumo", INDIGO, "EEECFB"),
    "gabarito": ("GABARITO", "gabarito", "15803D", "EEF8F1"),
    "fonte": ("CONSULTE", "fonte", "0A5BD8", "E8F1FE"),
    "refletir": ("PARA REFLETIR", "refletir", "6D28D9", "F3EEFD"),
    "analogia": ("ANALOGIA", "analogia", "0E7C78", "E7F6F5"),
    "saiba": ("SAIBA MAIS", "info", INDIGO, "EEECFB"),
    "importante": ("IMPORTANTE", "atencao", "C2410C", "FFF1E7"),
    "curiosidade": ("CURIOSIDADE", "dica", "15803D", "EAF7EE"),
}
CAIXA_PADRAO = ("", "info", INDIGO, "EEECFB")

ICONES_PALAVRAS = {  # icone: palavras do titulo que o sugerem
    "book": "conceito fundamentos introducao nocoes origem evolucao historia fontes teoria",
    "scales": "direito principios justica equidade igualdade etica lei legislacao",
    "gavel": "julgamento tribunal processo reclamacao conflitos jurisprudencia judicial",
    "handshake": "relacao acordo negociacao parceria contrato emprego vinculo",
    "users": "coletivo sindical sindicato equipe grupo pessoas trabalhadores organizacao",
    "user": "empregado sujeito pessoa perfil",
    "buildings": "empregador empresa terceirizacao grupo economico sucessao",
    "signature": "contrato modalidades assinatura registro",
    "money": "remuneracao salario salarial pagamento",
    "coins": "verbas rescisorias custos financeiro",
    "receipt": "contracheque holerite recibo",
    "clock": "jornada horas horario ponto",
    "calendar": "ferias repouso descanso prazo calendario intervalos",
    "pause": "suspensao interrupcao afastamento",
    "door": "extincao rescisao dispensa desligamento",
    "shield": "estabilidade garantias protecao seguranca",
    "hardhat": "seguranca riscos ocupacionais nr normas regulamentadoras epi",
    "firstaid": "acidente doencas socorros emergencia",
    "heartbeat": "saude",
    "warning": "periculosidade perigo risco",
    "flask": "insalubridade quimico agentes",
    "brain": "mental psicossociais assedio estresse",
    "megaphone": "greve reivindicacao",
    "chats": "comunicacao dialogo negociacao coletiva",
    "hourglass": "prescricao decadencia tempo",
    "clipboard": "gestao programa plano gerenciamento",
    "equals": "igualdade equiparacao",
    "crown": "confianca altos cargos",
    "house": "domestico",
    "tractor": "rural",
    "student": "aprendiz estagio",
    "laptop": "teletrabalho plataformas digital tecnologia",
}
ICONE_FINAL = "flag"

PALAVRAS_MINUSCULAS = {"a", "o", "as", "os", "e", "de", "da", "do", "das", "dos", "em", "na", "no",
                       "nas", "nos", "para", "por", "com", "sem", "ao", "aos", "à", "às", "um", "uma"}


def sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def titulo_curso(s):
    palavras = s.strip().split()
    out = []
    for i, p in enumerate(palavras):
        low = p.lower()
        if i > 0 and low in PALAVRAS_MINUSCULAS:
            out.append(low)
        elif len(p) <= 4 and p.isupper() and sem_acento(p).isalpha() and low not in PALAVRAS_MINUSCULAS and i > 0 and p in ("NR", "CLT", "SUS", "LGPD", "INSS", "FGTS", "TI", "RH"):
            out.append(p)
        else:
            out.append(low[:1].upper() + low[1:])
    return " ".join(out)


def slug(s, n=70):
    s = sem_acento(s)
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")
    return s[:n].rstrip("_")


# ---------------------------------------------------------------- leitura
def _on(el, tag):
    x = el.find(qn(tag)) if el is not None else None
    return x is not None and x.get(qn("w:val")) not in ("0", "false")


def ler_runs(p):
    out = []
    for r in p.iter(qn("w:r")):
        rpr = r.find(qn("w:rPr"))
        b, i = _on(rpr, "w:b"), _on(rpr, "w:i")
        t = ""
        for ch in r:
            if ch.tag == qn("w:t"):
                t += ch.text or ""
            elif ch.tag == qn("w:tab"):
                t += "\t"
            elif ch.tag in (qn("w:br"), qn("w:cr")) and ch.get(qn("w:type")) != "page":
                t += "\n"
        if not t:
            continue
        if out and out[-1][1] == b and out[-1][2] == i:
            out[-1][0] += t
        else:
            out.append([t, b, i])
    return out


class Leitor:
    def __init__(self, caminho):
        self.doc = docx.Document(caminho)
        self.formatos = {}
        try:
            num = self.doc.part.numbering_part.element
            absf = {}
            for a in num.findall(qn("w:abstractNum")):
                lv = a.find(qn("w:lvl"))
                fmt = lv.find(qn("w:numFmt")).get(qn("w:val")) if lv is not None and lv.find(qn("w:numFmt")) is not None else "bullet"
                absf[a.get(qn("w:abstractNumId"))] = fmt
            for n in num.findall(qn("w:num")):
                self.formatos[n.get(qn("w:numId"))] = absf.get(n.find(qn("w:abstractNumId")).get(qn("w:val")), "bullet")
        except Exception:
            pass

    def paragrafo(self, p):
        ppr = p.find(qn("w:pPr"))
        estilo, num, jc, ind_l = "", None, "", 0
        if ppr is not None:
            ps = ppr.find(qn("w:pStyle"))
            if ps is not None:
                sid = ps.get(qn("w:val"))
                try:
                    estilo = self.doc.styles.get_by_id(sid).name if False else sid
                except Exception:
                    estilo = sid
            np_ = ppr.find(qn("w:numPr"))
            if np_ is not None and np_.find(qn("w:numId")) is not None:
                nid = np_.find(qn("w:numId")).get(qn("w:val"))
                lvl = np_.find(qn("w:ilvl")).get(qn("w:val")) if np_.find(qn("w:ilvl")) is not None else "0"
                if nid != "0":
                    num = (nid, int(lvl), self.formatos.get(nid, "bullet"))
            j = ppr.find(qn("w:jc"))
            jc = j.get(qn("w:val")) if j is not None else ""
            ind = ppr.find(qn("w:ind"))
            if ind is not None:
                ind_l = int(ind.get(qn("w:left")) or ind.get(qn("w:start")) or 0)
        runs = ler_runs(p)
        texto = "".join(r[0] for r in runs).strip()
        nivel = 0
        m = re.match(r"(?i)heading\s*(\d)|t[ií]?tulo\s*(\d)", estilo or "")
        if m:
            nivel = int(m.group(1) or m.group(2))
        return {"tipo": "p", "nivel": nivel, "runs": runs, "texto": texto, "num": num, "jc": jc, "ind": ind_l}

    def tabela(self, t):
        linhas = []
        for tr in t.findall(qn("w:tr")):
            cels = []
            for tc in tr.findall(qn("w:tc")):
                tcpr = tc.find(qn("w:tcPr"))
                span = 1
                fill = ""
                if tcpr is not None:
                    gs = tcpr.find(qn("w:gridSpan"))
                    span = int(gs.get(qn("w:val"))) if gs is not None else 1
                    shd = tcpr.find(qn("w:shd"))
                    fill = (shd.get(qn("w:fill")) or "") if shd is not None else ""
                blocos = [self.paragrafo(p) for p in tc.findall(qn("w:p"))]
                cels.append({"span": span, "fill": fill, "blocos": blocos})
            linhas.append(cels)
        grid = [int(g.get(qn("w:w")) or 0) for g in t.findall(qn("w:tblGrid") + "/" + qn("w:gridCol"))]
        ncol = len(grid) or max(sum(c["span"] for c in l) for l in linhas)
        if len(linhas) == 1 and ncol == 1:
            cel = linhas[0][0]["blocos"]
            cel = [b for b in cel if b["texto"]]
            titulo = cel[0]["texto"] if cel else ""
            return {"tipo": "caixa", "titulo": titulo, "blocos": cel[1:]}
        return {"tipo": "tabela", "linhas": linhas, "grid": grid, "ncol": ncol}

    def blocos(self):
        out = []
        for el in self.doc.element.body.iterchildren():
            if el.tag == qn("w:p"):
                b = self.paragrafo(el)
                b["quebra"] = 'w:type="page"' in el.xml or "pageBreakBefore" in el.xml
                out.append(b)
            elif el.tag == qn("w:tbl"):
                out.append(self.tabela(el))
        return out


RE_CAP = re.compile(r"(?i)^cap[ií]tulo\s+(\d+)\s*[\.:\-–]?\s*(.*)$")
RE_UNI = re.compile(r"(?i)^unidade\s+([IVXLC]+|\d+)\b\.?\s*(.*)$")


def estruturar(caminho):
    blocos = Leitor(caminho).blocos()
    curso = ""
    for b in blocos:  # capa: maior linha em caixa alta antes do sumario ou do primeiro titulo
        if b["tipo"] != "p":
            continue
        if b["nivel"] == 1 or sem_acento(b["texto"].upper()) in ("SUMARIO", "INDICE"):
            break
        t = b["texto"]
        if t.isupper() and len(t) > len(curso) and t not in ("CURSO",) and "\t" not in t and not RE_UNI.match(t) and not RE_CAP.match(t):
            curso = t
    inicio, capitulos, final = [], [], []
    atual, estado, unidade = None, "capa", None
    i = 0
    while i < len(blocos):
        b = blocos[i]
        if b["tipo"] == "p" and b["nivel"] == 0 and RE_UNI.match(b["texto"]) and estado != "capa":
            m = RE_UNI.match(b["texto"])
            rotulo = "UNIDADE " + m.group(1).upper()
            nome = m.group(2).strip()
            if not nome:  # titulo da unidade no proximo paragrafo com texto
                j = i + 1
                while j < len(blocos) and blocos[j]["tipo"] == "p" and not blocos[j]["texto"]:
                    j += 1
                if j < len(blocos) and blocos[j]["tipo"] == "p" and blocos[j]["nivel"] != 1:
                    nome = blocos[j]["texto"]
            unidade = {"rotulo": rotulo, "nome": nome}
            estado = "unidade"
            i += 1
            continue
        if b["tipo"] == "p" and b["nivel"] == 1:
            m = RE_CAP.match(b["texto"])
            if m:
                atual = {"n": int(m.group(1)), "titulo": m.group(2).strip(), "unidade": unidade, "blocos": []}
                capitulos.append(atual)
                estado = "cap"
            elif not capitulos:
                atual = {"titulo": b["texto"], "blocos": []}
                inicio.append(atual)
                estado = "inicio"
            else:
                atual = {"titulo": b["texto"], "blocos": []}
                final.append(atual)
                estado = "final"
            i += 1
            continue
        if estado in ("cap", "inicio", "final") and atual is not None:
            atual["blocos"].append(b)
        i += 1
    return {"curso": curso, "inicio": inicio, "capitulos": capitulos, "final": final}


def sugerir_icone(texto, usados):
    t = sem_acento(texto.lower())
    pont = []
    for ic, pal in ICONES_PALAVRAS.items():
        s = sum(t.count(p) * (2 if len(p) > 6 else 1) for p in pal.split())
        if s:
            pont.append((s, ic))
    pont.sort(reverse=True)
    for _, ic in pont:
        if ic != (usados[-1] if usados else None):
            return ic
    return "book" if (usados[-1:] != ["book"]) else "lightbulb"



def maiuscula(t):
    for k, ch in enumerate(t):
        if ch.isalpha():
            return t[:k] + ch.upper() + t[k + 1:]
    return t


def pontuar(blocos):
    """Ponto final no ultimo paragrafo com texto da celula, se ainda nao terminar em pontuacao."""
    blocos = copy.deepcopy(blocos)
    for b in reversed(blocos):
        if b.get("texto"):
            runs = [r for r in b["runs"] if r[0].strip()]
            if runs and runs[-1][0].rstrip()[-1:] not in ".;:!?":
                runs[-1][0] = runs[-1][0].rstrip() + "."
                b["texto"] = b["texto"].rstrip() + "."
            break
    return blocos


# ---------------------------------------------------------------- XML de saida
def t_xml(texto):
    partes = []
    for k, linha in enumerate(texto.split("\n")):
        if k:
            partes.append("<w:br/>")
        for j, seg in enumerate(linha.split("\t")):
            if j:
                partes.append("<w:tab/>")
            if seg:
                partes.append(f'<w:t xml:space="preserve">{escape(seg)}</w:t>')
    return "".join(partes)


def r_xml(texto, b=False, i=False, cor=None, sz=None, fonte=None, caps=False, esp=None):
    rpr = ""
    if fonte:
        rpr += f'<w:rFonts w:ascii="{fonte}" w:hAnsi="{fonte}" w:cs="{fonte}"/>'
    if b:
        rpr += "<w:b/><w:bCs/>"
    if i:
        rpr += "<w:i/><w:iCs/>"
    if caps:
        rpr += "<w:caps/>"
    if cor:
        rpr += f'<w:color w:val="{cor}"/>'
    if esp:
        rpr += f'<w:spacing w:val="{esp}"/>'
    if sz:
        rpr += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    return f"<w:r>{'<w:rPr>' + rpr + '</w:rPr>' if rpr else ''}{t_xml(texto)}</w:r>"


def p_xml(estilo, conteudo, extra_ppr=""):
    return f'<w:p><w:pPr><w:pStyle w:val="{estilo}"/>{extra_ppr}</w:pPr>{conteudo}</w:p>'


def runs_xml(runs, cor=None, forcar_b=None):
    return "".join(r_xml(t, b if forcar_b is None else forcar_b, i, cor=cor) for t, b, i in runs)


ESTILOS = f"""
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCCorpo"><w:name w:val="PC Corpo"/><w:basedOn w:val="Normal"/><w:qFormat/>
<w:pPr><w:spacing w:before="0" w:after="140" w:line="300" w:lineRule="auto"/><w:jc w:val="both"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_CORPO}" w:hAnsi="{FONTE_CORPO}" w:cs="{FONTE_CORPO}"/><w:color w:val="{TEXTO}"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCTitulo1"><w:name w:val="PC Titulo 1"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/><w:qFormat/>
<w:pPr><w:keepNext/><w:spacing w:before="240" w:after="200" w:line="264" w:lineRule="auto"/><w:jc w:val="left"/><w:outlineLvl w:val="0"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="{INDIGO}"/><w:sz w:val="44"/><w:szCs w:val="44"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCTitulo2"><w:name w:val="PC Titulo 2"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="600" w:after="140" w:line="264" w:lineRule="auto"/><w:jc w:val="left"/><w:outlineLvl w:val="1"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="{INDIGO}"/><w:sz w:val="30"/><w:szCs w:val="30"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCTitulo3"><w:name w:val="PC Titulo 3"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/><w:qFormat/>
<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="480" w:after="100"/><w:jc w:val="left"/><w:outlineLvl w:val="2"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="{VIOLETA}"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCRotulo"><w:name w:val="PC Rotulo"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/>
<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="120"/><w:jc w:val="left"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:caps/><w:color w:val="0377A0"/><w:spacing w:val="20"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCLegenda"><w:name w:val="PC Legenda"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/>
<w:pPr><w:keepNext/><w:spacing w:before="200" w:after="100"/><w:jc w:val="left"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="{INDIGO}"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCCitacao"><w:name w:val="PC Citacao"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/>
<w:pPr><w:keepNext/><w:pBdr><w:left w:val="single" w:sz="24" w:space="10" w:color="{CIANO}"/></w:pBdr><w:spacing w:before="120" w:after="60"/><w:ind w:left="454" w:right="454"/><w:jc w:val="left"/></w:pPr>
<w:rPr><w:i/><w:iCs/><w:color w:val="{TEXTO_SUAVE}"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCCitacaoAutor"><w:name w:val="PC Citacao Autor"/><w:basedOn w:val="PCCorpo"/><w:next w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="200"/><w:ind w:left="454" w:right="454"/><w:jc w:val="right"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="{VIOLETA}"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCLista"><w:name w:val="PC Lista"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="80"/><w:ind w:left="425" w:hanging="284"/><w:jc w:val="left"/></w:pPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCQuestao"><w:name w:val="PC Questao"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:keepNext/><w:spacing w:before="280" w:after="100"/></w:pPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCAlternativa"><w:name w:val="PC Alternativa"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:keepNext/><w:spacing w:before="0" w:after="60"/><w:ind w:left="680" w:hanging="340"/><w:jc w:val="left"/></w:pPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCCaixa"><w:name w:val="PC Caixa"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="80" w:line="276" w:lineRule="auto"/><w:jc w:val="both"/></w:pPr>
<w:rPr><w:color w:val="1F2340"/><w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCCaixaTitulo"><w:name w:val="PC Caixa Titulo"/><w:basedOn w:val="PCCaixa"/>
<w:pPr><w:keepNext/><w:spacing w:before="40" w:after="100"/><w:jc w:val="left"/></w:pPr>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCTabela"><w:name w:val="PC Tabela"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="0" w:line="252" w:lineRule="auto"/><w:jc w:val="left"/></w:pPr>
<w:rPr><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCTabelaCab"><w:name w:val="PC Tabela Cabecalho"/><w:basedOn w:val="PCTabela"/>
<w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}" w:cs="{FONTE_TITULO}"/><w:b/><w:bCs/><w:color w:val="FFFFFF"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCEspaco"><w:name w:val="PC Espaco"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:sz w:val="14"/><w:szCs w:val="14"/></w:rPr></w:style>
<w:style w:type="paragraph" w:customStyle="1" w:styleId="PCReferencia"><w:name w:val="PC Referencia"/><w:basedOn w:val="PCCorpo"/>
<w:pPr><w:spacing w:before="0" w:after="140"/><w:ind w:left="340" w:hanging="340"/><w:jc w:val="left"/></w:pPr><w:rPr><w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>
"""

NUMERACAO_ABS = f"""
<w:abstractNum w:abstractNumId="9001"><w:multiLevelType w:val="hybridMultilevel"/>
<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="●"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="425" w:hanging="284"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:color w:val="{CIANO}"/><w:sz w:val="16"/></w:rPr></w:lvl>
<w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="○"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="851" w:hanging="284"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:color w:val="{VIOLETA}"/><w:sz w:val="16"/></w:rPr></w:lvl>
</w:abstractNum>
<w:abstractNum w:abstractNumId="9002"><w:multiLevelType w:val="hybridMultilevel"/>
<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="425" w:hanging="340"/></w:pPr><w:rPr><w:rFonts w:ascii="{FONTE_TITULO}" w:hAnsi="{FONTE_TITULO}"/><w:b/><w:color w:val="{INDIGO}"/><w:sz w:val="19"/></w:rPr></w:lvl>
<w:lvl w:ilvl="1"><w:start w:val="1"/><w:numFmt w:val="lowerLetter"/><w:lvlText w:val="%2)"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="851" w:hanging="340"/></w:pPr><w:rPr><w:color w:val="{VIOLETA}"/></w:rPr></w:lvl>
</w:abstractNum>
"""


ORDEM = {
    "pPr": "pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange",
    "tblPr": "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription",
    "tcPr": "cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark",
    "trPr": "cnfStyle divId gridBefore gridAfter wBefore wAfter cantSplit trHeight tblHeader tblCellSpacing jc hidden",
    "tblBorders": "top start left bottom end right insideH insideV",
    "tblCellMar": "top start left bottom end right",
}


def ordenar(raiz):
    """Coloca os filhos de pPr/tblPr/tcPr/trPr na ordem exigida pelo esquema do Word."""
    for tag, ordem in ORDEM.items():
        pos = {qn("w:" + n): i for i, n in enumerate(ordem.split())}
        for el in raiz.iter(qn("w:" + tag)):
            filhos = list(el)
            vistos, unicos = set(), []
            for f in filhos:
                if f.tag in vistos and f.tag != qn("w:rPr"):
                    continue
                vistos.add(f.tag)
                unicos.append(f)
            for f in filhos:
                el.remove(f)
            for f in sorted(unicos, key=lambda f: pos.get(f.tag, 999)):
                el.append(f)


class Montador:
    """Monta um .docx a partir do modelo de layout, bloco a bloco."""

    def __init__(self, base, curso):
        self.doc = docx.Document(base)
        self.partes = []
        self.img_id = 1000
        self.num_id = 9100
        self.nums = []
        self.cache_img = {}
        st = self.doc.styles.element
        for el in parse_xml(f"<w:styles {NS}>{ESTILOS}</w:styles>"):
            st.append(el)
        self._cabecalho(curso)

    def _cabecalho(self, curso):
        tam = 22 if len(curso) <= 42 else 19 if len(curso) <= 52 else 16 if len(curso) <= 64 else 14
        for rel in self.doc.part.rels.values():
            if rel.reltype.endswith("/header"):
                el = rel.target_part.element
                for t in el.iter(qn("w:t")):
                    if "Insira o nome" in (t.text or ""):
                        t.text = curso
                        rpr = t.getparent().find(qn("w:rPr"))
                        if rpr is not None:
                            for old in rpr.findall(qn("w:sz")) + rpr.findall(qn("w:szCs")):
                                rpr.remove(old)
                            rpr.append(parse_xml(f'<w:sz {NS} w:val="{tam}"/>'))
                            rpr.append(parse_xml(f'<w:szCs {NS} w:val="{tam}"/>'))

    # imagens
    def img(self, caminho, larg_cm, alt_cm=None, descr=""):
        if caminho not in self.cache_img:
            rid, image = self.doc.part.get_or_add_image(str(caminho))
            self.cache_img[caminho] = (rid, image.px_width, image.px_height)
        rid, pw, ph = self.cache_img[caminho]
        cx = int(larg_cm * 360000)
        cy = int(alt_cm * 360000) if alt_cm else int(cx * ph / pw)
        self.img_id += 1
        k = self.img_id
        return (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
                f'<wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="{k}" name="Ilustracao {k}" descr="{escape(descr)}"/>'
                f'<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic>'
                f'<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr>'
                f'<pic:cNvPr id="{k}" name="ilustracao{k}.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/>'
                f'<a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
                f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')

    def add(self, xml):
        self.partes.append(xml)

    def novo_num(self, fmt):
        self.num_id += 1
        absid = "9002" if fmt != "bullet" else "9001"
        over = '<w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride>' if fmt != "bullet" else ""
        self.nums.append(f'<w:num w:numId="{self.num_id}"><w:abstractNumId w:val="{absid}"/>{over}</w:num>')
        return self.num_id

    # blocos
    def paragrafos(self, blocos, contexto="corpo"):
        """Converte paragrafos lidos em XML. contexto: corpo | caixa | tabela"""
        out = []
        lista_src, lista_dst = None, None
        estilo_txt = {"corpo": "PCCorpo", "caixa": "PCCaixa", "tabela": "PCTabela"}[contexto]
        for k, b in enumerate(blocos):
            if not b["texto"]:
                continue
            if b["num"]:
                nid, lvl, fmt = b["num"]
                if lista_src != (nid, fmt):
                    lista_dst = self.novo_num(fmt)
                    lista_src = (nid, fmt)
                ind = '<w:ind w:left="340" w:hanging="255"/>' if contexto != "corpo" and lvl == 0 else ""
                estilo = "PCLista" if contexto == "corpo" else estilo_txt
                out.append(p_xml(estilo, runs_xml(b["runs"]),
                                 f'<w:numPr><w:ilvl w:val="{min(lvl,1)}"/><w:numId w:val="{lista_dst}"/></w:numPr>{ind}'))
                continue
            lista_src = None
            txt = b["texto"]
            if contexto == "corpo":
                if b["ind"] >= 1000 and b["jc"] != "right":
                    out.append(p_xml("PCCitacao", runs_xml(b["runs"])))
                    continue
                if b["jc"] == "right" and len(txt) < 120:
                    out.append(p_xml("PCCitacaoAutor", r_xml(txt)))
                    continue
                if re.match(r"^(Tabela|Quadro|Figura)\s+\d+", txt):
                    out.append(p_xml("PCLegenda", r_xml(txt)))
                    continue
                m = re.match(r"^(Questão\s+\d+\.?)\s*(.*)$", txt, re.S)
                if m:
                    resto = list(b["runs"])
                    cab = m.group(1)
                    # remove o cabecalho dos runs originais
                    acc, novos = 0, []
                    for t, bb, ii in resto:
                        if acc >= len(cab):
                            novos.append([t, bb, ii])
                        elif acc + len(t) > len(cab):
                            novos.append([t[len(cab) - acc:], bb, ii])
                        acc += len(t)
                    if novos:
                        novos[0][0] = novos[0][0].lstrip()
                    out.append(p_xml("PCQuestao", r_xml(cab + " ", b=True, cor=INDIGO, fonte=FONTE_TITULO, sz=20) + runs_xml(novos)))
                    continue
                m = re.match(r"^([a-eA-E]\))\s*(.*)$", txt, re.S)
                if m and len(txt) < 600:
                    ultimo = k + 1 >= len(blocos) or not re.match(r"^[a-eA-E]\)", blocos[k + 1].get("texto", "") or "")
                    extra = '<w:keepNext w:val="0"/>' if ultimo else ""
                    out.append(p_xml("PCAlternativa", r_xml(m.group(1) + "\t", b=True, cor=VIOLETA) + r_xml(maiuscula(m.group(2))), extra))
                    continue
            if contexto == "caixa":
                todos_b = all(r[1] for r in b["runs"] if r[0].strip())
                if todos_b and len(txt) < 80:
                    out.append(p_xml("PCCaixa", r_xml(txt, b=True, cor=INDIGO, fonte=FONTE_TITULO, sz=19), '<w:keepNext/><w:spacing w:before="120" w:after="60"/>'))
                    continue
            jc = '<w:jc w:val="center"/>' if (contexto == "tabela" and b["jc"] == "center") else ""
            out.append(p_xml(estilo_txt, runs_xml(b["runs"]), jc))
        return "".join(out)

    def caixa(self, bloco):
        titulo = bloco["titulo"]
        sem = sem_acento(titulo.upper())
        cfg = CAIXA_PADRAO
        for chave, c in CAIXAS.items():
            if sem.startswith(sem_acento(c[0])):
                cfg = c
                break
        _, badge, cor, fundo = cfg
        if ":" in titulo:
            rot, sub = titulo.split(":", 1)
            tit = r_xml(rot.strip().upper() + "  ", b=True, cor=cor) + r_xml(sub.strip(), b=True, cor="1F2340")
        else:
            tit = r_xml(titulo.strip().upper(), b=True, cor=cor)
        corpo = self.paragrafos(bloco["blocos"], "caixa")
        tam = len(titulo) + sum(len(b.get("texto", "")) for b in bloco["blocos"])
        cant = "<w:cantSplit/>" if tam < 900 else ""
        icone = self.img(ASSETS / "badges" / f"{badge}.png", 0.78, descr=titulo.split(":")[0].title())
        c1, c2 = 880, LARGURA - 880
        self.add(f'<w:tbl><w:tblPr><w:tblW w:w="{LARGURA}" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
                 f'<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>'
                 f'<w:tblCellMar><w:top w:w="170" w:type="dxa"/><w:left w:w="150" w:type="dxa"/><w:bottom w:w="110" w:type="dxa"/><w:right w:w="200" w:type="dxa"/></w:tblCellMar>'
                 f'<w:tblLook w:val="0000"/></w:tblPr><w:tblGrid><w:gridCol w:w="{c1}"/><w:gridCol w:w="{c2}"/></w:tblGrid>'
                 f'<w:tr><w:trPr>{cant}</w:trPr>'
                 f'<w:tc><w:tcPr><w:tcW w:w="{c1}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="{fundo}"/>'
                 f'<w:tcMar><w:left w:w="200" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tcMar></w:tcPr>'
                 f'{p_xml("PCCaixa", icone, "<w:spacing w:before=\"0\" w:after=\"0\"/>")}</w:tc>'
                 f'<w:tc><w:tcPr><w:tcW w:w="{c2}" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="{fundo}"/></w:tcPr>'
                 f'{p_xml("PCCaixaTitulo", tit)}{corpo}</w:tc></w:tr></w:tbl>')
        self.add(p_xml("PCEspaco", "", '<w:spacing w:before="0" w:after="160"/>'))

    def tabela(self, bloco):
        grid = bloco["grid"] or [1] * bloco["ncol"]
        tot = sum(grid) or 1
        cols = [max(600, int(LARGURA * g / tot)) for g in grid]
        cols[-1] += LARGURA - sum(cols)
        n = len(cols)
        linhas = bloco["linhas"]
        primeira = linhas[0]
        cab = any(c["fill"] and c["fill"].upper() not in ("FFFFFF", "AUTO") and int(c["fill"][:2], 16) < 0x80 for c in primeira if re.match(r"^[0-9A-Fa-f]{6}$", c["fill"] or "")) \
            or all(all(r[1] for b in c["blocos"] for r in b["runs"] if r[0].strip()) for c in primeira)
        xml = [f'<w:tbl><w:tblPr><w:tblW w:w="{LARGURA}" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
               f'<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:right w:val="nil"/><w:insideV w:val="nil"/>'
               f'<w:bottom w:val="single" w:sz="8" w:space="0" w:color="{INDIGO}"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="DCD8F2"/></w:tblBorders>'
               f'<w:tblCellMar><w:top w:w="80" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tblCellMar>'
               f'<w:tblLook w:val="0000"/></w:tblPr><w:tblGrid>{"".join(f"<w:gridCol w:w=\"{c}\"/>" for c in cols)}</w:tblGrid>']
        zebra = 0
        for li, linha in enumerate(linhas):
            eh_cab = li == 0 and cab
            grupo = len(linha) == 1 and n > 1
            trpr = "<w:cantSplit/>" + ("<w:tblHeader/>" if eh_cab else "")
            xml.append(f"<w:tr><w:trPr>{trpr}</w:trPr>")
            pos = 0
            for cel in linha:
                span = n if grupo else min(cel["span"], n - pos)
                w = sum(cols[pos:pos + span])
                pos += span
                if eh_cab:
                    fill = INDIGO
                    conteudo = "".join(p_xml("PCTabelaCab", r_xml(b["texto"])) for b in cel["blocos"] if b["texto"]) or p_xml("PCTabelaCab", "")
                elif grupo:
                    fill = "E6E2F8"
                    conteudo = "".join(p_xml("PCTabela", r_xml(b["texto"].upper(), b=True, cor=VIOLETA, fonte=FONTE_TITULO, sz=16)) for b in cel["blocos"] if b["texto"]) or p_xml("PCTabela", "")
                else:
                    fill = "FFFFFF" if zebra % 2 == 0 else "F4F2FC"
                    conteudo = self.paragrafos(pontuar(cel["blocos"]), "tabela") or p_xml("PCTabela", "")
                gs = f'<w:gridSpan w:val="{span}"/>' if span > 1 else ""
                xml.append(f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>{gs}<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/><w:vAlign w:val="center"/></w:tcPr>{conteudo}</w:tc>')
            if not eh_cab and not grupo:
                zebra += 1
            xml.append("</w:tr>")
        xml.append("</w:tbl>")
        self.add("".join(xml))
        self.add(p_xml("PCEspaco", "", '<w:spacing w:before="0" w:after="200"/>'))

    def titulo_icone(self, texto, badge, sub=None, quebra=False):
        ppr = '<w:pageBreakBefore/>' if quebra else ""
        ic = self.img(ASSETS / "badges" / f"{badge}.png", 0.95, descr=texto)
        sub_xml = (r_xml("\n") + r_xml(sub.upper(), b=True, cor="0377A0", sz=16, esp=20)) if sub else ""
        self.add(f'<w:tbl><w:tblPr><w:tblW w:w="{LARGURA}" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
                 f'<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:right w:val="nil"/><w:insideV w:val="nil"/><w:insideH w:val="nil"/>'
                 f'<w:bottom w:val="single" w:sz="8" w:space="0" w:color="DCD8F2"/></w:tblBorders>'
                 f'<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="120" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar>'
                 f'<w:tblLook w:val="0000"/></w:tblPr><w:tblGrid><w:gridCol w:w="760"/><w:gridCol w:w="{LARGURA-760}"/></w:tblGrid>'
                 f'<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc><w:tcPr><w:tcW w:w="760" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>'
                 f'{p_xml("PCCorpo", ic, ppr + "<w:keepNext/><w:spacing w:before=\"0\" w:after=\"0\"/>")}</w:tc>'
                 f'<w:tc><w:tcPr><w:tcW w:w="{LARGURA-760}" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>'
                 f'{p_xml("PCTitulo2", r_xml(texto) + sub_xml, "<w:spacing w:before=\"0\" w:after=\"0\"/>")}</w:tc></w:tr></w:tbl>')
        self.add(p_xml("PCEspaco", "", '<w:keepNext/><w:spacing w:before="0" w:after="160"/>'))

    def h2(self, texto):
        m = re.match(r"^(\d+(?:\.\d+)+)\s+(.*)$", texto)
        if m:
            self.add(p_xml("PCTitulo2", r_xml(m.group(1) + "  ", cor=CIANO) + r_xml(m.group(2))))
        else:
            self.add(p_xml("PCTitulo2", r_xml(texto)))

    def conteudo(self, blocos, tipo_secao=""):
        buf = []

        def solta():
            if buf:
                self.add(self.paragrafos(buf, "corpo"))
                buf.clear()

        for b in blocos:
            if b["tipo"] == "caixa":
                solta()
                self.caixa(b)
            elif b["tipo"] == "tabela":
                solta()
                self.tabela(b)
            elif b["nivel"] == 2:
                solta()
                if re.match(r"(?i)^exerc[ií]cios", b["texto"]):
                    self.titulo_icone("Exercícios", "exercicios", sub=b["texto"], quebra=True)
                else:
                    self.h2(b["texto"])
            elif b["nivel"] >= 3:
                solta()
                self.add(p_xml("PCTitulo3", r_xml(b["texto"])))
            elif tipo_secao == "glossario" and b["texto"] and ":" in b["texto"][:70] and not b["num"]:
                solta()
                termo, resto = b["texto"].split(":", 1)
                self.add(p_xml("PCCorpo", r_xml(termo.strip() + ":", b=True, cor=INDIGO) + r_xml(resto), '<w:jc w:val="left"/><w:spacing w:after="120"/>'))
            elif tipo_secao == "referencias" and b["texto"] and not b["num"] and not re.match(r"^(Tabela|Quadro)\s+\d+", b["texto"]):
                solta()
                self.add(p_xml("PCReferencia", runs_xml(b["runs"])))
            else:
                buf.append(b)
        solta()

    def abertura(self, banner, rotulo, titulo, primeira=False):
        if rotulo:
            self.add(p_xml("PCRotulo", r_xml(rotulo), "" if primeira else "<w:pageBreakBefore/>"))
            quebra = ""
        else:
            quebra = "" if primeira else "<w:pageBreakBefore/>"
        self.add(p_xml("PCCorpo", self.img(banner, 15.0, descr=titulo), quebra + '<w:keepNext/><w:spacing w:before="0" w:after="120"/><w:jc w:val="left"/>'))
        self.add(p_xml("PCTitulo1", r_xml(titulo)))

    def pagina_em_branco(self):
        sect = self.doc.element.body.find(qn("w:sectPr"))
        pg = sect.find(qn("w:pgSz"))
        mar = sect.find(qn("w:pgMar"))
        self.add(f'<w:p><w:pPr><w:sectPr><w:type w:val="nextPage"/>{pg.xml if pg is not None else ""}{mar.xml if mar is not None else ""}</w:sectPr></w:pPr></w:p>'
                 .replace(' xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"', ""))

    def salvar(self, caminho):
        body = self.doc.element.body
        sect = body.find(qn("w:sectPr"))
        for el in list(body):
            if el is not sect:
                body.remove(el)
        frag = parse_xml(f"<w:body {NS}>{''.join(self.partes)}</w:body>")
        for el in list(frag):
            sect.addprevious(el)
        ordenar(body)
        numel = self.doc.part.numbering_part.element
        for el in parse_xml(f"<w:numbering {NS}>{NUMERACAO_ABS}{''.join(self.nums)}</w:numbering>"):
            if el.tag == qn("w:abstractNum"):
                primeiro_num = numel.find(qn("w:num"))
                if primeiro_num is not None:
                    primeiro_num.addprevious(el)
                else:
                    numel.append(el)
            else:
                numel.append(el)
        self.doc.core_properties.title = ""
        self.doc.save(caminho)


# ---------------------------------------------------------------- ilustracoes
def _fonte(peso, tam):
    for c in [f"/usr/share/fonts/truetype/google-fonts/Poppins-{peso}.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]:
        if os.path.exists(c):
            return ImageFont.truetype(c, tam)
    return ImageFont.load_default()


def _hex(h, a=255):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def banner(destino, icone, rotulo, grande, semente=1):
    """Ilustracao de abertura 1800x600: gradiente da marca, formas e icone tematico."""
    W, H = 1800, 600
    fundo = Image.new("RGBA", (W, H))
    a, b = _hex("2A1C9E"), _hex("6346D8")
    grad = Image.linear_gradient("L").rotate(-90).resize((W, H))
    fundo = Image.composite(Image.new("RGBA", (W, H), b), Image.new("RGBA", (W, H), a), grad)
    cam = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(cam)
    # pontos
    for gx in range(70, 420, 34):
        for gy in range(56, 230, 34):
            d.ellipse([gx - 3, gy - 3, gx + 3, gy + 3], fill=(255, 255, 255, 46))
    # aneis concentricos atras do icone
    cx, cy = 1430, 300
    for r, al in [(330, 30), (270, 44), (215, 60)]:
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(0, 200, 248, al), width=6)
    # sinais de mais e bolhas
    import random
    rnd = random.Random(semente)
    for _ in range(6):
        x, y, s = rnd.randint(980, 1760), rnd.randint(40, 560), rnd.randint(14, 26)
        d.line([x - s, y, x + s, y], fill=(0, 220, 255, 150), width=7)
        d.line([x, y - s, x, y + s], fill=(0, 220, 255, 150), width=7)
    for _ in range(5):
        x, y, s = rnd.randint(900, 1780), rnd.randint(30, 570), rnd.randint(8, 18)
        d.ellipse([x - s, y - s, x + s, y + s], fill=(255, 255, 255, 70))
    # disco do icone
    d.ellipse([cx - 165, cy - 165, cx + 165, cy + 165], fill=_hex("00C8F8"))
    d.ellipse([cx - 165, cy - 165, cx + 165, cy + 165], outline=(255, 255, 255, 230), width=8)
    fundo = Image.alpha_composite(fundo, cam)
    ic_path = ASSETS / "icons" / f"{icone}.png"
    if not ic_path.exists():
        ic_path = ASSETS / "icons" / "book.png"
    ic = Image.open(ic_path).convert("RGBA").resize((200, 200), Image.LANCZOS)
    cor_ic = Image.new("RGBA", ic.size, _hex("1E1478"))
    cor_ic.putalpha(ic.split()[3])
    fundo.alpha_composite(cor_ic, (cx - 100, cy - 100))
    d = ImageDraw.Draw(fundo)
    f1 = _fonte("SemiBold", 40)
    x0 = 90
    # rotulo com espacamento
    xx = x0
    for ch in rotulo.upper():
        d.text((xx, 250 if grande.isdigit() else 200), ch, font=f1, fill=_hex("7FE6FF"))
        xx += d.textlength(ch, font=f1) + 6
    if grande.isdigit():
        f2 = _fonte("Bold", 250)
        d.text((x0 - 8, 255), grande, font=f2, fill=(255, 255, 255, 255))
    else:
        tam = 130
        f2 = _fonte("Bold", tam)
        while d.textlength(grande, font=f2) > 980 and tam > 60:
            tam -= 6
            f2 = _fonte("Bold", tam)
        d.text((x0 - 4, 262), grande, font=f2, fill=(255, 255, 255, 255))
    # cantos arredondados
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, H - 1], radius=54, fill=255)
    fundo.putalpha(mask)
    fundo.save(destino)


# ---------------------------------------------------------------- fontes embutidas (Word)
def embutir_fontes(caminho):
    """Embute a Poppins (regular e negrito) no .docx para o Word mostrar igual ao PDF."""
    arqs = {"embedRegular": "/usr/share/fonts/truetype/google-fonts/Poppins-Regular.ttf",
            "embedBold": "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"}
    if not all(os.path.exists(p) for p in arqs.values()):
        return False
    tmp = caminho + ".tmp"
    with zipfile.ZipFile(caminho) as zin:
        itens = {n: zin.read(n) for n in zin.namelist()}
    ft = itens["word/fontTable.xml"].decode("utf8")
    rels_nome = "word/_rels/fontTable.xml.rels"
    rels = itens.get(rels_nome, b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>').decode("utf8")
    embeds = ""
    for k, (tag, p) in enumerate(arqs.items()):
        guid = str(uuid.uuid4()).upper()
        chave = bytes.fromhex(guid.replace("-", ""))[::-1]
        dados = bytearray(open(p, "rb").read())
        for i in range(32):
            dados[i] ^= chave[i % 16]
        nome = f"fonts/poppins{k}.odttf"
        itens["word/" + nome] = bytes(dados)
        rid = f"rIdPop{k}"
        rels = rels.replace("</Relationships>", f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font" Target="{nome}"/></Relationships>')
        embeds += f'<w:{tag} r:id="{rid}" w:fontKey="{{{guid}}}"/>'
    if 'xmlns:r=' not in ft[:600]:
        ft = ft.replace("<w:fonts ", '<w:fonts xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ', 1)
    ft = ft.replace("</w:fonts>", f'<w:font w:name="Poppins"><w:charset w:val="00"/><w:family w:val="auto"/><w:pitch w:val="variable"/>{embeds}</w:font></w:fonts>')
    itens["word/fontTable.xml"] = ft.encode("utf8")
    itens[rels_nome] = rels.encode("utf8")
    ct = itens["[Content_Types].xml"].decode("utf8")
    if 'Extension="odttf"' not in ct:
        ct = ct.replace("<Types ", "<Types ", 1).replace("</Types>", '<Default Extension="odttf" ContentType="application/vnd.openxmlformats-officedocument.obfuscatedFont"/></Types>')
    itens["[Content_Types].xml"] = ct.encode("utf8")
    from lxml import etree
    st = etree.fromstring(itens["word/settings.xml"])
    if st.find(qn("w:embedTrueTypeFonts")) is None:
        antes = [qn("w:" + n) for n in "writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText printFractionalCharacterWidth printFormsData".split()]
        idx = 0
        for k, f in enumerate(st):
            if f.tag in antes:
                idx = k + 1
        st.insert(idx, etree.Element(qn("w:saveSubsetFonts")))
        st.insert(idx, etree.Element(qn("w:embedTrueTypeFonts")))
    itens["word/settings.xml"] = etree.tostring(st, xml_declaration=True, encoding="UTF-8", standalone=True)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for n, v in itens.items():
            zout.writestr(n, v)
    os.replace(tmp, caminho)
    return True


# ---------------------------------------------------------------- PDF
def para_pdf(arquivos, pasta):
    if not arquivos:
        return
    perfil = tempfile.mkdtemp(prefix="lo_perfil_")
    env = dict(os.environ, SAL_USE_VCLPLUGIN="svp")
    cmd = ["soffice", f"-env:UserInstallation=file://{perfil}", "--headless", "--convert-to", "pdf", "--outdir", str(pasta)] + [str(a) for a in arquivos]
    try:
        subprocess.run(cmd, env=env, check=True, timeout=600, capture_output=True)
    except Exception:
        for cand in glob.glob("/mnt/skills/public/docx/scripts/office/soffice.py") + glob.glob(str(Path.home() / ".claude/skills/**/docx/scripts/office/soffice.py"), recursive=True):
            sys.path.insert(0, str(Path(cand).parent.parent))
            from office.soffice import run_soffice
            run_soffice(["--headless", "--convert-to", "pdf", "--outdir", str(pasta)] + [str(a) for a in arquivos], check=True, timeout=600, capture_output=True)
            break
        else:
            raise
    finally:
        shutil.rmtree(perfil, ignore_errors=True)


# ---------------------------------------------------------------- comandos
def base_docx(destino):
    with zipfile.ZipFile(MODELOS / "layout.dotx") as zin, zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zout:
        for n in zin.namelist():
            v = zin.read(n)
            if n == "[Content_Types].xml":
                v = v.replace(b"wordprocessingml.template.main+xml", b"wordprocessingml.document.main+xml")
                if b"numbering+xml" not in v:
                    v = v.replace(b"</Types>", b'<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/></Types>')
            if n == "word/_rels/document.xml.rels" and b"relationships/numbering" not in v:
                v = v.replace(b"</Relationships>", b'<Relationship Id="rIdNumPC" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>')
            zout.writestr(n, v)
        if "word/numbering.xml" not in zin.namelist():
            zout.writestr("word/numbering.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"></w:numbering>')


def analisar(curso_docx, plano_json):
    e = estruturar(curso_docx)
    usados = []
    caps = []
    for c in e["capitulos"]:
        secoes = " ".join(b["texto"] for b in c["blocos"] if b["tipo"] == "p" and b["nivel"] == 2)
        ic = sugerir_icone(c["titulo"] + " " + c["titulo"] + " " + secoes, usados)
        usados.append(ic)
        uni = f'{c["unidade"]["rotulo"]} · {c["unidade"]["nome"]}' if c["unidade"] else ""
        caps.append({"n": c["n"], "titulo": c["titulo"], "unidade": uni, "icone": ic})
    plano = {"curso": titulo_curso(e["curso"]) if e["curso"] else "",
             "inicio": [s["titulo"] for s in e["inicio"]],
             "capitulos": caps,
             "final": [s["titulo"] for s in e["final"]]}
    json.dump(plano, open(plano_json, "w", encoding="utf8"), ensure_ascii=False, indent=1)
    print(f'Curso: {plano["curso"]}')
    print(f'Inicio (vai no arquivo da Aula 01): {plano["inicio"]}')
    for c in caps:
        print(f'  Cap. {c["n"]:>2}: {c["titulo"]}  [{c["unidade"]}]  icone={c["icone"]}')
    print(f'Encerramento: {plano["final"]}')
    print(f'Icones disponiveis: {", ".join(sorted(json.load(open(ASSETS / "icons.json"))["icons"]))}')


def tipo_secao(titulo):
    t = sem_acento(titulo.lower())
    if t.startswith("gloss"):
        return "glossario"
    if t.startswith("refer") or t.startswith("bibliograf"):
        return "referencias"
    return ""


def gerar(curso_docx, plano_json, saida):
    plano = json.load(open(plano_json, encoding="utf8"))
    e = estruturar(curso_docx)
    saida = Path(saida)
    saida.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="aulas_"))
    base = tmp / "base.docx"
    base_docx(base)
    curso = plano["curso"]
    icones = {c["n"]: c for c in plano["capitulos"]}
    gerados, para_converter = [], []
    for idx, cap in enumerate(e["capitulos"]):
        info = icones.get(cap["n"], {})
        m = Montador(base, curso)
        primeira = True
        if idx == 0:
            m.pagina_em_branco()
            for s in e["inicio"]:
                bn = tmp / f"banner_inicio_{slug(s['titulo'])}.png"
                banner(bn, "compass", "Apresentação", "Boas-vindas", 7)
                m.abertura(bn, "", s["titulo"], primeira=primeira)
                primeira = False
                m.conteudo(s["blocos"])
        bn = tmp / f"banner_{cap['n']:02d}.png"
        banner(bn, info.get("icone", "book"), "Capítulo", f"{cap['n']:02d}", cap["n"])
        rot = info.get("unidade") or (f'{cap["unidade"]["rotulo"]} · {cap["unidade"]["nome"]}' if cap["unidade"] else "")
        m.abertura(bn, rot, info.get("titulo") or cap["titulo"], primeira=primeira)
        m.conteudo(cap["blocos"])
        nome = f"Aula_{cap['n']:02d}_{slug(info.get('titulo') or cap['titulo'], 60)}"
        destino = saida / f"{nome}.docx"
        m.salvar(destino)
        embutir_fontes(str(destino))
        gerados.append(destino)
    if e["final"]:
        m = Montador(base, curso)
        bn = tmp / "banner_final.png"
        banner(bn, ICONE_FINAL, "Para fechar o curso", "Encerramento", 99)
        m.abertura(bn, "", e["final"][0]["titulo"], primeira=True)
        m.conteudo(e["final"][0]["blocos"], tipo_secao(e["final"][0]["titulo"]))
        for s in e["final"][1:]:
            ts = tipo_secao(s["titulo"])
            badge = {"glossario": "glossario", "referencias": "referencias"}.get(ts, "leituras" if "leitura" in sem_acento(s["titulo"].lower()) else "info")
            m.titulo_icone(s["titulo"], badge, quebra=True)
            m.conteudo(s["blocos"], ts)
        partes = [s["titulo"] for s in e["final"]]
        nome = "Encerramento_" + slug("_".join(slug(p, 20) for p in partes), 70)
        destino = saida / f"{nome}.docx"
        m.salvar(destino)
        embutir_fontes(str(destino))
        gerados.append(destino)
    faltando = [str(g) for g in gerados if not g.exists()]
    shutil.rmtree(tmp, ignore_errors=True)
    print("Arquivos gerados:")
    for g in gerados:
        print("  ", g.name, "OK" if g.exists() else "FALTOU")
    if faltando:
        sys.exit("Falha ao gerar: " + ", ".join(faltando))


def verificar(pasta):
    pasta = Path(pasta)
    tmp = Path(tempfile.mkdtemp(prefix="verif_"))
    docs = sorted(pasta.glob("*.docx"))
    if docs:
        para_pdf(docs, tmp)
    pdfs = sorted(pasta.glob("*.pdf")) + sorted(tmp.glob("*.pdf"))
    (pasta / "_conferencia").mkdir(exist_ok=True)
    for pdf in pdfs:
        pref = tmp / pdf.stem
        subprocess.run(["pdftoppm", "-jpeg", "-r", "28", str(pdf), str(pref)], check=True)
        pags = sorted(tmp.glob(pdf.stem + "-*.jpg"))
        ims = [Image.open(p) for p in pags]
        if not ims:
            continue
        w, h = ims[0].size
        col = 8
        lin = (len(ims) + col - 1) // col
        folha = Image.new("RGB", (w * col, h * lin), "white")
        for k, im in enumerate(ims):
            folha.paste(im, ((k % col) * w, (k // col) * h))
        folha.save(pasta / "_conferencia" / f"{pdf.stem}.jpg", quality=80)
        print(f"{pdf.name}: {len(ims)} paginas")
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    cmd = sys.argv[1]
    if cmd == "analisar":
        analisar(sys.argv[2], sys.argv[3])
    elif cmd == "gerar":
        gerar(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "verificar":
        verificar(sys.argv[2])
    else:
        sys.exit(__doc__)
