#!/usr/bin/env python3
"""Pensar Cursos: preenche o modelo de ementa (Programa do Curso).

Uso:
  python3 ementa.py ementa.json PASTA_SAIDA

ementa.json:
{
  "curso": "Nome do Curso",
  "ementa": "Um paragrafo, ate 550 caracteres.",
  "conteudo": ["Topico 1", "Topico 2", "..."],      (ate 650 caracteres somados)
  "bibliografia": ["SOBRENOME, Nome. Obra. Editora.", "..."]  (ate 8 obras)
}
Gera Ementa_<curso>.docx e Ementa_<curso>.pdf.
"""
import copy, json, re, sys, zipfile
from pathlib import Path

from lxml import etree

sys.path.insert(0, str(Path(__file__).resolve().parent))
from converter import MODELOS, para_pdf, sem_acento, slug  # noqa: E402

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NSM = {"w": W}
LIMITES = {"ementa": 550, "conteudo": 650, "bibliografia": 1000}


def q(t):
    return "{%s}%s" % (W, t)


def texto(el):
    return "".join(t.text or "" for t in el.iter(q("t")))


def tamanho(chars, limite):
    """Tamanho da fonte (meios-pontos) para caber no cartao do modelo."""
    if chars <= limite:
        return 22
    if chars <= limite * 1.2:
        return 20
    if chars <= limite * 1.45:
        return 18
    return 17


def preencher_secao(txbx, paragrafos_txt, sz, justificar):
    ps = txbx.findall(q("p"))
    cab, corpo = ps[0], ps[1:]
    modelo = corpo[0] if corpo else copy.deepcopy(cab)
    for p in corpo:
        txbx.remove(p)
    rmod = modelo.find(q("r"))
    rpr = copy.deepcopy(rmod.find(q("rPr"))) if rmod is not None and rmod.find(q("rPr")) is not None else etree.SubElement(etree.Element(q("r")), q("rPr"))
    for tag in ("sz", "szCs"):
        for old in rpr.findall(q(tag)):
            rpr.remove(old)
        etree.SubElement(rpr, q(tag)).set(q("val"), str(sz))
    for txt in paragrafos_txt:
        p = etree.SubElement(txbx, q("p"))
        ppr = copy.deepcopy(modelo.find(q("pPr"))) if modelo.find(q("pPr")) is not None else etree.Element(q("pPr"))
        jc = ppr.find(q("jc"))
        if jc is None:
            jc = etree.Element(q("jc"))
            ppr.insert(0, jc)
        jc.set(q("val"), "both" if justificar else "left")
        sp = ppr.find(q("spacing"))
        if sp is None:
            sp = etree.Element(q("spacing"))
            ppr.insert(1, sp)
        sp.set(q("before"), "0")
        sp.set(q("after"), "40")
        p.append(ppr)
        r = etree.SubElement(p, q("r"))
        r.append(copy.deepcopy(rpr))
        t = etree.SubElement(r, q("t"))
        t.text = txt
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")


def linhas_titulo(nome, por_linha=26):
    palavras, linhas, atual = nome.upper().split(), [], ""
    for p in palavras:
        if atual and len(atual) + 1 + len(p) > por_linha:
            linhas.append(atual)
            atual = p
        else:
            atual = (atual + " " + p).strip()
    if atual:
        linhas.append(atual)
    return linhas


def preencher_titulo(txbx, nome):
    ps = txbx.findall(q("p"))
    modelo = ps[0]
    for p in ps:
        txbx.remove(p)
    linhas = linhas_titulo(nome)
    sz = 40
    if len(linhas) > 3:
        linhas = linhas_titulo(nome, 34)
        sz = 32
    if len(linhas) > 3:
        linhas = linhas_titulo(nome, 42)
        sz = 26
    rmod = modelo.find(q("r"))
    for ln in linhas:
        p = etree.SubElement(txbx, q("p"))
        if modelo.find(q("pPr")) is not None:
            p.append(copy.deepcopy(modelo.find(q("pPr"))))
        r = etree.SubElement(p, q("r"))
        rpr = copy.deepcopy(rmod.find(q("rPr")))
        for tag in ("sz", "szCs"):
            for old in rpr.findall(q(tag)):
                rpr.remove(old)
            etree.SubElement(rpr, q(tag)).set(q("val"), str(sz))
        r.append(rpr)
        t = etree.SubElement(r, q("t"))
        t.text = ln


def gerar(dados_json, saida):
    d = json.load(open(dados_json, encoding="utf8"))
    saida = Path(saida)
    saida.mkdir(parents=True, exist_ok=True)
    conteudo = "; ".join(x.strip().rstrip(";.") for x in d["conteudo"]) + "."
    biblio = [b.strip() for b in d["bibliografia"]]
    avisos = []
    for k, v in (("ementa", d["ementa"]), ("conteudo", conteudo), ("bibliografia", " ".join(biblio))):
        if len(v) > LIMITES[k] * 1.45:
            avisos.append(f"{k}: {len(v)} caracteres, acima do que cabe no cartao ({LIMITES[k]}). Encurte.")
    if len(biblio) > 9:
        avisos.append(f"bibliografia: {len(biblio)} obras; use no maximo 8.")
    if avisos:
        sys.exit("Texto grande demais para o modelo:\n" + "\n".join(avisos))
    destino = saida / f"Ementa_{slug(d['curso'], 60)}.docx"
    with zipfile.ZipFile(MODELOS / "ementa.dotx") as zin:
        itens = {n: zin.read(n) for n in zin.namelist()}
    raiz = etree.fromstring(itens["word/document.xml"])
    for txbx in raiz.iter(q("txbxContent")):
        ps = txbx.findall(q("p"))
        if not ps:
            continue
        cab = sem_acento(texto(ps[0]).strip().upper())
        if cab.startswith("EMENTA"):
            preencher_secao(txbx, [d["ementa"].strip()], tamanho(len(d["ementa"]), LIMITES["ementa"]), True)
        elif cab.startswith("CONTEUDO"):
            preencher_secao(txbx, [conteudo], tamanho(len(conteudo), LIMITES["conteudo"]), True)
        elif cab.startswith("BIBLIOGRAFIA"):
            total = sum(len(b) for b in biblio) + 60 * max(0, len(biblio) - 6)
            preencher_secao(txbx, biblio, tamanho(total, LIMITES["bibliografia"]), False)
        elif any(r.get(q("val")) == "FFFFFF" for r in txbx.iter(q("color"))) and texto(txbx).strip():
            preencher_titulo(txbx, d["curso"])
    itens["word/document.xml"] = etree.tostring(raiz, xml_declaration=True, encoding="UTF-8", standalone=True)
    itens["[Content_Types].xml"] = itens["[Content_Types].xml"].replace(b"wordprocessingml.template.main+xml", b"wordprocessingml.document.main+xml")
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zout:
        for n, v in itens.items():
            zout.writestr(n, v)
    para_pdf([destino], saida)
    print("Gerados:", destino.name, destino.with_suffix(".pdf").name if destino.with_suffix(".pdf").exists() else "(PDF falhou)")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    gerar(sys.argv[1], sys.argv[2])
